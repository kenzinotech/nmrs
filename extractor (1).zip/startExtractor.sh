#!/bin/bash

java -jar IHVN_Data_Extractor.jar
